Morphing Modal Window
=========

A call-to-action button that animates and turns into a full-size modal window.

[Article on CodyHouse](http://codyhouse.co/gem/morphing-modal-window/)

[Demo](http://codyhouse.co/demo/morphing-modal-window/index.html)
 
[Terms](http://codyhouse.co/terms/)
